import json
from sheets_service import ler_primeira_aba_disponivel, planilha_configurada
from ai import gerar_texto


def resumo_planilha(nome_planilha):
    if not planilha_configurada(nome_planilha):
        return f"A planilha {nome_planilha} ainda não está com ID configurado no código."

    aba, linhas = ler_primeira_aba_disponivel(nome_planilha)
    contexto = {
        "planilha": nome_planilha,
        "aba_lida": aba,
        "total_linhas": len(linhas),
        "colunas": list(linhas[0].keys()) if linhas else [],
        "amostra": linhas[:20],
        "ultimas_linhas": linhas[-10:],
    }
    return gerar_texto(
        f"Faça um resumo operacional da planilha {nome_planilha}.",
        json.dumps(contexto, ensure_ascii=False, indent=2),
    )


def relatorio_geral():
    partes = []
    for nome in ["farol", "stageout", "abs", "labor", "inventario"]:
        if not planilha_configurada(nome):
            continue
        try:
            aba, linhas = ler_primeira_aba_disponivel(nome)
            partes.append({
                "planilha": nome,
                "aba": aba,
                "total_linhas": len(linhas),
                "colunas": list(linhas[0].keys()) if linhas else [],
                "ultimas_linhas": linhas[-8:],
            })
        except Exception as e:
            partes.append({"planilha": nome, "erro": str(e)})

    if not partes:
        return "Nenhuma planilha com ID configurado ainda."

    return gerar_texto(
        "Gere um relatório executivo da operação com base nas planilhas.",
        json.dumps(partes, ensure_ascii=False, indent=2),
    )
