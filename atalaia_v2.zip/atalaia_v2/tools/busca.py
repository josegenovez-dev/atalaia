import json
import re
from sheets_service import buscar_em_todas
from ai import gerar_texto


def extrair_codigo(texto):
    match = re.search(r"[A-Za-z0-9\-]{5,}", texto)
    return match.group(0) if match else None


def executar(texto, codigo=None):
    codigo = codigo or extrair_codigo(texto)
    if not codigo:
        return "Me envie um código, pedido, LH ou rastreio para eu buscar."

    resultados = buscar_em_todas(codigo)
    if not resultados:
        return f"Não encontrei registros para: {codigo}"

    contexto = json.dumps(resultados[:8], ensure_ascii=False, indent=2)
    return gerar_texto(
        f"Explique os resultados encontrados para o código {codigo}.",
        contexto,
    )
