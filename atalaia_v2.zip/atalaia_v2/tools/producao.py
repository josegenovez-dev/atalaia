import json
from sheets_service import ler_primeira_aba_disponivel, planilha_configurada
from ai import gerar_texto

PALAVRAS_PRODUCAO = [
    "produz", "produção", "produtividade", "esteira", "total", "qtd", "quantidade",
    "pacotes", "pedido", "pedidos", "processado", "processados"
]


def executar(pergunta):
    if not planilha_configurada("farol"):
        return "A planilha Farol ainda não está com ID configurado no código."

    aba, linhas = ler_primeira_aba_disponivel("farol")

    if not linhas:
        return "A planilha Farol está vazia ou sem registros."

    # Envia uma amostra + total de linhas. O Gemini resume conforme as colunas reais.
    contexto = {
        "planilha": "farol",
        "aba_lida": aba,
        "total_linhas": len(linhas),
        "colunas": list(linhas[0].keys()) if linhas else [],
        "ultimas_linhas": linhas[-20:],
    }

    return gerar_texto(
        pergunta + "\nCalcule/resuma a produção com base nos dados disponíveis. Se houver coluna de quantidade/produção, some quando possível.",
        json.dumps(contexto, ensure_ascii=False, indent=2),
    )
