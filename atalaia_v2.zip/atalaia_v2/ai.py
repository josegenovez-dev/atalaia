import json
from google import genai
from config import GEMINI_API_KEY


def get_client():
    if not GEMINI_API_KEY:
        raise Exception("GEMINI_API_KEY não configurada")
    return genai.Client(api_key=GEMINI_API_KEY)


def gerar_texto(pergunta, contexto=""):
    try:
        client = get_client()
        prompt = f"""
Você é o Atalaia, assistente interno de logística.
Responda em português do Brasil.
Seja direto, útil e profissional.
Não invente dados operacionais.
Use apenas o contexto quando houver dados.

Contexto:
{contexto}

Mensagem do usuário:
{pergunta}
"""
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
        )
        return response.text or "Não consegui gerar resposta."
    except Exception as e:
        print("ERRO GEMINI:", repr(e))
        return f"Tive erro ao consultar a IA Gemini: {e}"


def classificar_intencao(texto):
    try:
        client = get_client()
        prompt = f"""
Classifique a intenção do usuário para um bot de logística.
Responda SOMENTE em JSON válido, sem markdown.

Intenções possíveis:
- ajuda
- status
- buscar_codigo
- producao_farol
- resumo_planilha
- relatorio
- conversa

Campos:
intent: string
codigo: string ou null
planilha: string ou null

Exemplos:
"/lh BR123" => {{"intent":"buscar_codigo","codigo":"BR123","planilha":null}}
"ver quanto a esteira produziu" => {{"intent":"producao_farol","codigo":null,"planilha":"farol"}}
"resumo do abs" => {{"intent":"resumo_planilha","codigo":null,"planilha":"abs"}}

Mensagem: {texto}
"""
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
        )
        raw = (response.text or "{}").strip()
        raw = raw.replace("```json", "").replace("```", "").strip()
        return json.loads(raw)
    except Exception as e:
        print("ERRO CLASSIFICANDO:", repr(e))
        return {"intent": "conversa", "codigo": None, "planilha": None}
