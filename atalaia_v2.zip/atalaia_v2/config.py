import os

APP_ID = os.getenv("APP_ID")
APP_SECRET = os.getenv("APP_SECRET")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GOOGLE_SERVICE_ACCOUNT_JSON = os.getenv("GOOGLE_SERVICE_ACCOUNT_JSON")
BASE_URL = "https://openapi.seatalk.io"

# Cadastre aqui suas planilhas.
# O ID é o trecho do link entre /d/ e /edit
PLANILHAS = {
    "farol": {
        "id": "COLE_AQUI_O_ID_DA_PLANILHA_FAROL",
        "abas": ["Farol", "Base", "Resumo"]
    },
    "stageout": {
        "id": "COLE_AQUI_O_ID_DA_PLANILHA_STAGEOUT",
        "abas": ["Base", "Resumo"]
    },
    "abs": {
        "id": "COLE_AQUI_O_ID_DA_PLANILHA_ABS",
        "abas": ["ABS", "Hoje"]
    },
    "labor": {
        "id": "COLE_AQUI_O_ID_DA_PLANILHA_LABOR",
        "abas": ["Labor", "HC"]
    },
    "inventario": {
        "id": "COLE_AQUI_O_ID_DA_PLANILHA_INVENTARIO",
        "abas": ["Inventário", "Base"]
    }
}
