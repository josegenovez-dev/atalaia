import json
import gspread
from google.oauth2.service_account import Credentials
from config import GOOGLE_SERVICE_ACCOUNT_JSON, PLANILHAS

_client = None


def get_client():
    global _client
    if _client:
        return _client

    if not GOOGLE_SERVICE_ACCOUNT_JSON:
        raise Exception("GOOGLE_SERVICE_ACCOUNT_JSON não configurado no Render")

    info = json.loads(GOOGLE_SERVICE_ACCOUNT_JSON)
    credentials = Credentials.from_service_account_info(
        info,
        scopes=[
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive",
        ],
    )
    _client = gspread.authorize(credentials)
    return _client


def planilha_configurada(nome):
    config = PLANILHAS.get(nome)
    return bool(config and "COLE_AQUI" not in config["id"])


def ler_aba(nome_planilha, nome_aba):
    config = PLANILHAS.get(nome_planilha)
    if not config:
        raise Exception(f"Planilha não cadastrada: {nome_planilha}")
    if "COLE_AQUI" in config["id"]:
        raise Exception(f"ID da planilha {nome_planilha} não configurado")

    gc = get_client()
    sheet = gc.open_by_key(config["id"])
    worksheet = sheet.worksheet(nome_aba)
    return worksheet.get_all_records()


def ler_primeira_aba_disponivel(nome_planilha):
    config = PLANILHAS.get(nome_planilha)
    if not config:
        raise Exception(f"Planilha não cadastrada: {nome_planilha}")

    ultimo_erro = None
    for aba in config["abas"]:
        try:
            return aba, ler_aba(nome_planilha, aba)
        except Exception as e:
            ultimo_erro = e
            print(f"Erro lendo {nome_planilha}/{aba}:", repr(e))

    raise Exception(f"Nenhuma aba funcionou em {nome_planilha}: {ultimo_erro}")


def buscar_em_todas(codigo):
    codigo = str(codigo).strip().lower()
    resultados = []

    for nome_planilha, config in PLANILHAS.items():
        if "COLE_AQUI" in config["id"]:
            continue

        for aba in config["abas"]:
            try:
                linhas = ler_aba(nome_planilha, aba)
                for numero_linha, linha in enumerate(linhas, start=2):
                    texto_linha = " ".join(str(v).lower() for v in linha.values())
                    if codigo in texto_linha:
                        resultados.append({
                            "planilha": nome_planilha,
                            "aba": aba,
                            "linha": numero_linha,
                            "dados": linha,
                        })
            except Exception as e:
                print(f"Erro buscando em {nome_planilha}/{aba}:", repr(e))

    return resultados
