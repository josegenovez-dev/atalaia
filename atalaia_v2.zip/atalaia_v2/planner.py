import re
from ai import classificar_intencao, gerar_texto
from tools import busca, producao, resumos


def ajuda():
    return """Comandos disponíveis:

/status
/ajuda
/buscar CÓDIGO
/lh CÓDIGO
/pedido CÓDIGO
/farol
/abs
/labor
/stageout
/inventario
/relatorio

Também pode perguntar naturalmente:
"Ver quanto a esteira produziu até agora"
"Onde está o pedido 12345?"
"Resumo do ABS"""


def processar(texto):
    texto = (texto or "").strip()
    lower = texto.lower()

    if not texto:
        return "Não recebi nenhuma mensagem."

    # Comandos rápidos, sem gastar IA
    if lower in ["/ajuda", "ajuda", "menu"]:
        return ajuda()

    if lower == "/status":
        return "Status: online.\nSeatalk: conectado.\nGemini: conectado.\nGoogle Sheets: conectado."

    if lower.startswith(("/buscar", "/lh", "/pedido")):
        return busca.executar(texto)

    if lower == "/farol":
        return producao.executar("Faça um resumo da produção da planilha Farol.")

    if lower == "/abs":
        return resumos.resumo_planilha("abs")

    if lower == "/labor":
        return resumos.resumo_planilha("labor")

    if lower == "/stageout":
        return resumos.resumo_planilha("stageout")

    if lower == "/inventario":
        return resumos.resumo_planilha("inventario")

    if lower == "/relatorio":
        return resumos.relatorio_geral()

    # Atalhos por palavras-chave
    if any(p in lower for p in ["esteira", "produziu", "produção", "farol", "produtividade"]):
        return producao.executar(texto)

    if re.search(r"[A-Za-z0-9\-]{5,}", texto) and any(p in lower for p in ["pedido", "lh", "rastreio", "codigo", "código"]):
        return busca.executar(texto)

    # IA decide a ferramenta
    decisao = classificar_intencao(texto)
    intent = decisao.get("intent")
    codigo = decisao.get("codigo")
    planilha = decisao.get("planilha")

    if intent == "buscar_codigo":
        return busca.executar(texto, codigo)

    if intent == "producao_farol":
        return producao.executar(texto)

    if intent == "resumo_planilha" and planilha:
        return resumos.resumo_planilha(planilha)

    if intent == "relatorio":
        return resumos.relatorio_geral()

    return gerar_texto(texto, "Sem consulta de planilha nesta mensagem.")
